﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Database_Example.Models;
using System.Net;
using Newtonsoft.Json.Linq;
using System.IO;
using Newtonsoft.Json;
using Database_Example.Tools;

namespace Database_Example.Windows
{
    /// <summary>
    /// Interaction logic for jSonStudentList.xaml
    /// </summary>
    public partial class jSonStudentList : Window
    {
        private DatabaseContext db = new DatabaseContext();
        private List<Student> StudentList = new List<Student>();
        
        public jSonStudentList()
        {
            InitializeComponent();

            BindStudentList();

            //List<jSonData> jSonDataList = jsonTools.GetjSonDataList<jSonData>();
            //dataGrid.ItemsSource = jSonDataList;

            //var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost:62720/api/values");
            //httpWebRequest.ContentType = "application/json";
            //httpWebRequest.Method = "GET";

            //var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            //using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            //{
            //    var result = streamReader.ReadToEnd();
            //    List<jSonData> jSonDataList = JsonConvert.DeserializeObject<List<jSonData>>(result);
            //    dataGrid.ItemsSource = jSonDataList;
            //}
        }

        private void BindStudentList()
        {
            List<jSonData> jSonDataList = jsonTools.GetjSonDataList<jSonData>();
            dataGrid.ItemsSource = jSonDataList;
        }

        private void btnNormalMode_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnEraseStudent_Click(object sender, RoutedEventArgs e)
        {
            Button ThisButon = sender as Button;
            int StudentID = Convert.ToInt32(ThisButon.Content);

            jSonData jsonData_Object = jsonTools.GetjSonData<jSonData>(StudentID);
            //Student Student_Object = db.Students.Find(StudentID);

            MessageBoxResult Result = MessageBox.Show("Ønsker du virkelig at slette eleven " + jsonData_Object.StudentName, "Slet Elev ?", MessageBoxButton.OKCancel);

            if (MessageBoxResult.OK == Result)
            {
                //db.Students.Remove(Student_Object);
                //db.SaveChanges();
                jsonTools.DeletejSonData(StudentID);
                BindStudentList();
            }
        }
    }
}
