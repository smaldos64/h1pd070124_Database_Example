﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database_Example.Models
{
    public class Student
    {
        public int StudentID { get; set; }

        public string StudentName { get; set; }

        public string StudentLastName { get; set; }

        public int TeamID { get; set; }
        public virtual Team Team { get; set; }

        public virtual ICollection<Course> Courses { get; set; }
    }
}
