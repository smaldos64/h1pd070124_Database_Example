﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Database_Example.Models;

namespace Database_Example
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {
        private DatabaseContext db = new DatabaseContext();
        private List<Student> StudentList = new List<Student>();

        public MainWindow()
        {
            InitializeComponent();

            //StudentList = db.Students.Where(t => t.TeamID == 1 && t.StudentName == "Jens").OrderBy(i => i.StudentID).ToList();
            StudentList = db.Students.Where(t => t.TeamID == 1).OrderBy(i => i.StudentName).ToList();
            dataGrid.ItemsSource = StudentList;
        }
    }
}
