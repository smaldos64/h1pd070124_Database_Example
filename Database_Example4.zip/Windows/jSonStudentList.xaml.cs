﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Database_Example.Models;
using System.Net;
using Newtonsoft.Json.Linq;
using System.IO;
using Newtonsoft.Json;
using Database_Example.Tools;
using Database_Example.Settings;

namespace Database_Example.Windows
{
    /// <summary>
    /// Interaction logic for jSonStudentList.xaml
    /// </summary>
    public partial class jSonStudentList : Window
    {
        private DatabaseContext db = new DatabaseContext();
        private List<Student> StudentList = new List<Student>();
        
        public jSonStudentList()
        {
            InitializeComponent();

            BindStudentList();
        }

        private void BindStudentList()
        {
            List<jSonStudentData> jSonDataList = jsonTools.GetjSonDataList<jSonStudentData>(MainWindow.Find_WEB_API_URL(WEB_API_CONTROLLER_ENUM.STUDENT_API_CONTROLLER));
            dataGrid.ItemsSource = jSonDataList;
        }

        private void btnNormalMode_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnEraseStudent_Click(object sender, RoutedEventArgs e)
        {
            Button ThisButon = sender as Button;
            int StudentID = Convert.ToInt32(ThisButon.Content);

            jSonStudentData Student_Object = jsonTools.GetjSonData<jSonStudentData>(StudentID, MainWindow.Find_WEB_API_URL(WEB_API_CONTROLLER_ENUM.STUDENT_API_CONTROLLER));
       
            MessageBoxResult Result = MessageBox.Show("Ønsker du virkelig at slette eleven " + Student_Object.StudentName, "Slet Elev ?", MessageBoxButton.OKCancel);

            if (MessageBoxResult.OK == Result)
            {
                jsonTools.DeletejSonData(StudentID + 50, MainWindow.Find_WEB_API_URL(WEB_API_CONTROLLER_ENUM.STUDENT_API_CONTROLLER));
                BindStudentList();
            }
        }

        private void btnModifyStudent_Click(object sender, RoutedEventArgs e)
        {
            Button ThisButon = sender as Button;
            int StudentID = Convert.ToInt32(ThisButon.Content);

            // Skift til ModifyStudentWindow vindue/view
            jSonModifyStudentWindow dlg = new jSonModifyStudentWindow(StudentID);
            dlg.ShowDialog();

            BindStudentList();
        }
    }
}
