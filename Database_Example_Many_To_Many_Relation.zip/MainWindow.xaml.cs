﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Database_Example.Models;
using Database_Example.Windows;
using Database_Example.Settings;
using Database_Example.ViewModels;

namespace Database_Example
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {
        private DatabaseContext db = new DatabaseContext();
        private List<Student> StudentList = new List<Student>();
        public static List<ProjectSettings> SettingsList = new List<ProjectSettings>();

        public MainWindow()
        {
            this.DataContext = new StudentCourseViewModel();
            InitializeComponent();
            
            BindStudentList();
            SetupWebApiUrls();
        }

        private void SetupWebApiUrls()
        {
            SettingsList.Clear();
            SettingsList.Add(new ProjectSettings(WEB_API_CONTROLLER_ENUM.STUDENT_API_CONTROLLER, 
                             Properties.Settings.Default.WEB_API_STUDENT_URL));
            SettingsList.Add(new ProjectSettings(WEB_API_CONTROLLER_ENUM.TEAM_API_CONTROLLER,
                             Properties.Settings.Default.WEB_API_TEAM_URL));
        }

        public static string Find_WEB_API_URL(WEB_API_CONTROLLER_ENUM This_Web_Api_Controller_Enum)
        {
            return (SettingsList.First(item => item.Web_Api_Controller_Enum == This_Web_Api_Controller_Enum).Web_Api_Controller_Url);
        }

        private void BindStudentList()
        {
            DatabaseContext db1 = new DatabaseContext();
            dataGrid.Items.Clear();

            StudentList = db1.Students.ToList();

            foreach (Student Student_Object in StudentList)
            {
                StudentCourseViewModel StudentCourseMethodWindow_Object = new StudentCourseViewModel(Student_Object);

                StudentCourseMethodWindow_Object.SetCourses(Student_Object);

                dataGrid.Items.Add(StudentCourseMethodWindow_Object);
            }

            //dataGrid.ItemsSource = StudentList;
        }

        private void btnEraseStudent_Click(object sender, RoutedEventArgs e)
        {
            Button ThisButon = sender as Button;
            int StudentID = Convert.ToInt32(ThisButon.Content);

            Student Student_Object = db.Students.Find(StudentID);

            MessageBoxResult Result = MessageBox.Show("Ønsker du virkelig at slette eleven " + Student_Object.StudentName, "Slet Elev ?", MessageBoxButton.OKCancel);

            if (MessageBoxResult.OK == Result)
            {
                db.Students.Remove(Student_Object);
                db.SaveChanges();
                BindStudentList();
            }
        }

        private void btnModifyStudent_Click(object sender, RoutedEventArgs e)
        {
            Button ThisButon = sender as Button;
            int StudentID = Convert.ToInt32(ThisButon.Content);

            // Skift til ModifyStudentWindow vindue/view
            ModifyStudentWindow dlg = new ModifyStudentWindow(StudentID);
            dlg.ShowDialog();

            BindStudentList();
        }

        private void btnNewStudent_Click(object sender, RoutedEventArgs e)
        {
            AddStudentWindow dlg = new AddStudentWindow();
            dlg.ShowDialog();

            BindStudentList();
        }

        private void btnjSonMode_Click(object sender, RoutedEventArgs e)
        {
            jSonStudentList dlg = new jSonStudentList();
            dlg.ShowDialog();
        }
    }
}
