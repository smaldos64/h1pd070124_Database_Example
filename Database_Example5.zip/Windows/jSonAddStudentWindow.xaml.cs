﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Database_Example.Models;
using Database_Example.Settings;
using Database_Example.Tools;

namespace Database_Example.Windows
{
    /// <summary>
    /// Interaction logic for jSonAddStudentWindow.xaml
    /// </summary>
    /// 
    
    public partial class jSonAddStudentWindow : Window
    {
        private List<jSonTeamData> TeamList;

        public jSonAddStudentWindow()
        {
            InitializeComponent();

            TeamList = TeamList = jsonTools.GetjSonDataList<jSonTeamData>(MainWindow.Find_WEB_API_URL(WEB_API_CONTROLLER_ENUM.TEAM_API_CONTROLLER));
            lvTeam.ItemsSource = TeamList;
        }

        private void btnSaveStudent_Click(object sender, RoutedEventArgs e)
        {
            jSonStudentData Student_Object = new jSonStudentData();

            Student_Object.StudentName = txtStudentName.Text;
            Student_Object.StudentLastName = txtStudentLastName.Text;
            Student_Object.TeamID = TeamList.ElementAt(lvTeam.SelectedIndex).TeamID;

            jsonTools.InsertjSonData<jSonStudentData>(Student_Object, MainWindow.Find_WEB_API_URL(WEB_API_CONTROLLER_ENUM.STUDENT_API_CONTROLLER));

            Close();
        }
    }
}
