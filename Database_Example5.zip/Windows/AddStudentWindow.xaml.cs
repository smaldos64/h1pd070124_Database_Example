﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Database_Example.Models;
using Database_Example;

namespace Database_Example.Windows
{
    /// <summary>
    /// Interaction logic for AddStudent.xaml
    /// </summary>
    public partial class AddStudentWindow : Window
    {
        private List<Team> TeamList;
        private DatabaseContext db = new DatabaseContext();

        public AddStudentWindow()
        {
            InitializeComponent();

            TeamList = db.Teams.ToList();
            lvTeam.ItemsSource = TeamList;
        }

        private void btnSaveStudent_Click(object sender, RoutedEventArgs e)
        {
            Student Student_Object = new Student();

            Student_Object.StudentName = txtStudentName.Text;
            Student_Object.StudentLastName = txtStudentLastName.Text;
            Student_Object.TeamID = TeamList.ElementAt(lvTeam.SelectedIndex).TeamID;
          
            db.Students.Add(Student_Object);
            db.SaveChanges();
            
            Close();
        }
    }
}
