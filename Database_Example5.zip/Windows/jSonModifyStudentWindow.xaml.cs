﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Database_Example.Models;
using Database_Example.Tools;
using Database_Example.Settings;

namespace Database_Example.Windows
{
    /// <summary>
    /// Interaction logic for jSonModifyStudentWindow.xaml
    /// </summary>
    public partial class jSonModifyStudentWindow : Window
    {
        private int StudentID = 0;
        private jSonStudentData Student_Object;
        private List<jSonTeamData> TeamList;
        //private DatabaseContext db = new DatabaseContext();

        public jSonModifyStudentWindow(int StudentID)
        {
            InitializeComponent();
            this.StudentID = StudentID;

            Student_Object = jsonTools.GetjSonData<jSonStudentData>(StudentID, MainWindow.Find_WEB_API_URL(WEB_API_CONTROLLER_ENUM.STUDENT_API_CONTROLLER));
            TeamList = jsonTools.GetjSonDataList<jSonTeamData>(MainWindow.Find_WEB_API_URL(WEB_API_CONTROLLER_ENUM.TEAM_API_CONTROLLER));
            lvTeam.ItemsSource = TeamList;

            bool SelectedItemFound = false;
            int Counter = 0;
            do
            {
                if (TeamList.ElementAt(Counter).TeamID == Student_Object.TeamID)
                {
                    SelectedItemFound = true;
                }
                else
                {
                    Counter++;
                }
            } while ((Counter < TeamList.Count) && (false == SelectedItemFound));

            if (true == SelectedItemFound)
            {
                lvTeam.SelectedIndex = Counter;
            }
            else
            {
                lvTeam.SelectedIndex = 0;
            }

            txtStudentName.Text = Student_Object.StudentName;
            txtStudentLastName.Text = Student_Object.StudentLastName;
        }

        private void btnSaveModifiedStudent_Click(object sender, RoutedEventArgs e)
        {
            Student_Object.StudentID = this.StudentID; 
            Student_Object.StudentName = txtStudentName.Text;
            Student_Object.StudentLastName = txtStudentLastName.Text;
            Student_Object.TeamID = TeamList.ElementAt(lvTeam.SelectedIndex).TeamID;

            jsonTools.ModifyjSonData<jSonStudentData>(StudentID, Student_Object, MainWindow.Find_WEB_API_URL(WEB_API_CONTROLLER_ENUM.STUDENT_API_CONTROLLER));
            
            Close();
        }
    }
}
