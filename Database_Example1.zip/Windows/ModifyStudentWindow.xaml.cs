﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Database_Example.Models;

namespace Database_Example.Windows
{
    /// <summary>
    /// Interaction logic for ModifyStudentWindow.xaml
    /// </summary>
    public partial class ModifyStudentWindow : Window
    {
        private int StudentID = 0;
        private Student Student_Object;
        private List<Team> TeamList;
        private DatabaseContext db = new DatabaseContext();

        public ModifyStudentWindow(int StudentID)
        {
            InitializeComponent();
            this.StudentID = StudentID;
            
            TeamList = db.Teams.ToList();
            Student_Object = db.Students.Find(StudentID);

            lvTeam.ItemsSource = TeamList;
            txtStudentName.Text = Student_Object.StudentName;
            txtStudentLastName.Text = Student_Object.StudentLastName;
        }

        private void btnSaveModifiedStudent_Click(object sender, RoutedEventArgs e)
        {
            Student_Object.StudentName = txtStudentName.Text;
            Student_Object.StudentLastName = txtStudentLastName.Text;
            Student_Object.TeamID = TeamList.ElementAt(lvTeam.SelectedIndex).TeamID;
            string TeamName = TeamList.ElementAt(lvTeam.SelectedIndex).TeamName;

            // Anden måde at lave ovennævnte kode på !!!
            Team Team_Object = TeamList.ElementAt(lvTeam.SelectedIndex);
            Student_Object.TeamID = Team_Object.TeamID;

            db.SaveChanges();

            Close();
        }
    }
}
