﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Database1.Models;

namespace Database1.Windows
{
    /// <summary>
    /// Interaction logic for StudentsWindow.xaml
    /// </summary>
    public partial class StudentsWindow : Window
    {
        private CodeModelDB db = new CodeModelDB();

        public StudentsWindow()
        {
            InitializeComponent();
            List<Student> StudentList = db.Students.ToList();
            dataStudents.ItemsSource = StudentList;
            //var ItemsSource = dataStudents.ItemsSource as IEnumerable;
            
            foreach (DataGridRow row in dataStudents.Items)
            {
                //DataGridB
            }

            for (int Counter = 0; Counter < dataStudents.Items.Count; Counter++)
            {
                Button MyControl = new Button();
                MyControl.Content = "";
                //MyControl.DataContext = dataStudents.Items.

                Grid.SetRow(MyControl, Counter);
                Grid.SetColumn(MyControl, 0);
                dataStudents.Children.Add(MyControl);
            } 
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
       
    }
}
