﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Database_Example.Properties;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Database_Example.Tools
{
    public class jsonTools
    {
        public static string WEB_API_URL = Properties.Settings.Default.WEB_API_URL;

        public static List<T> GetjSonDataList<T>()
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(WEB_API_URL);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "GET";

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                List<T> jSonDataList = JsonConvert.DeserializeObject<List<T>>(result);
                return jSonDataList;
            }
        }

        public static T GetjSonData<T>(int ID)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(WEB_API_URL + "/" + ID.ToString());
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "GET";

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                T jSonDataObject = JsonConvert.DeserializeObject<T>(result);
                return jSonDataObject;
            }
        }

        public static void DeletejSonData(int ID)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(WEB_API_URL + "/" + ID.ToString());
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "DELETE";

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
        }
    }
}
